/**
 * 
 */
/**
 * @author Lenovo
 *
 */
module Number_Guessing_Game {
}